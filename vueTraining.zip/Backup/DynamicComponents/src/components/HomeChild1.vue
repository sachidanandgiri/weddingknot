<template>
  <div>
    <h1>Child1 Components of Home</h1>
  </div>
</template>

<script>
export default {};
</script>
