<template>
  <div>
    <h1>Child Components of Home</h1>
  </div>
</template>

<script>
export default {};
</script>
