<template>
  <div class="about">
    <h1>This is an about page</h1>
    <div class="row">
      <div class="col-md-6">
        <PostUpper></PostUpper>
      </div>
      <div class="col-md-6">
        <PostLower></PostLower>
      </div>
    </div>
  </div>
</template>

<script>
import PostUpper from "../components/PostTitleUpper.vue";
import PostLower from "../components/PostTitleLower.vue";
export default {
  components: {
    PostUpper,
    PostLower
  }
};
</script>
