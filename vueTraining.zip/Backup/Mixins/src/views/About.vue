<template>
  <div class="about">
    <h1>This is an about page</h1>
    <ul>
      <li v-for="post in posts" :key="post.id">{{ post.title }}</li>
    </ul>
  </div>
</template>

<script>
import axios from "axios";
export default {
  data() {
    return {
      posts: {}
    };
  },
  created() {
    // axios
    //   .get("https://jsonplaceholder.typicode.com/posts")
    //   .then(result => {
    //     this.posts = result.data;
    //   })
    //   .catch(error => {
    //     console.log(error);
    //   });
  },
  mounted() {
    setTimeout(() => {
      axios
        .get("https://jsonplaceholder.typicode.com/posts")
        .then(result => {
          this.posts = result.data;
        })
        .catch(error => {
          console.log(error);
        });
    }, 5000);
  }
};
</script>
