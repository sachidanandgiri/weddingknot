<template>
  <div class="home">
    <button @click="show1">Show Child1</button>
    <button @click="show2">Show Child2</button>
    <component :is="componentName"></component>
  </div>
</template>

<script>
import ChildHome from "../components/HomeChild.vue";
import HomeChild1 from "../components/HomeChild1.vue";
export default {
  data() {
    return {
      componentName: ""
    };
  },
  components: {
    ChildHome,
    HomeChild1
  },
  methods: {
    show1() {
      this.componentName = "ChildHome";
    },
    show2() {
      this.componentName = "HomeChild1";
    }
  }
};
</script>
