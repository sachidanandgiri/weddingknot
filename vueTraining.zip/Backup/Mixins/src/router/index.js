import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Counter from "../views/Counter.vue";
import Post from "../views/Post.vue";

Vue.use(VueRouter);

var isAuth = true;

var ifIsAuthe = (to, from, next) => {
  console.log("Before enter");
  // Logic
  if (isAuth) {
    next();
  } else {
    next("/");
  }
};

const routes = [
  {
    path: "/",
    name: "home",
    component: Home
  },
  {
    path: "/counter",
    name: "counter",
    component: Counter,
    beforeEnter: ifIsAuthe
  },
  {
    path: "/posts",
    name: "posts",
    component: Post,
    beforeEnter: ifIsAuthe
  },
  {
    path: "/about",
    name: "about",
    component: () => import("../views/About.vue"),
    beforeEnter: ifIsAuthe
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

router.beforeEach((to, from, next) => {
  console.log("Before Each guard is active");
  next();
});

export default router;
