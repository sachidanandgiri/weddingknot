import Vue from "vue";
import "./plugins/axios";
import App from "./App.vue";
import router from "./router";
import store from "./store";

Vue.config.productionTip = false;

Vue.directive("bgColor", {
  inserted: function(el, binding) {
    console.log(binding);
    el.style.background = binding.value.bg;
  }
});

Vue.filter("toLower", value => {
  return value.toLowerCase();
});

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
