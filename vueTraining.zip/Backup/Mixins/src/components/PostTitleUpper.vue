<template>
  <div class="about">
    <h1>This is an about page</h1>
    <ul>
      <li v-for="post in posts" :key="post.id">{{ post.title | upperCase }}</li>
    </ul>
  </div>
</template>

<script>
import { post } from "../mixins/posts";
export default {
  mixins: [post],
  filters: {
    upperCase(value) {
      return value.toUpperCase();
    }
  }
};
</script>
