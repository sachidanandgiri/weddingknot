import axios from "axios";
export const post = {
  data() {
    return {
      posts: {}
    };
  },
  created() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then(result => {
        this.posts = result.data;
      })
      .catch(error => {
        console.log(error);
      });
  },
  mounted() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then(result => {
        this.posts = result.data;
      })
      .catch(error => {
        console.log(error);
      });
  }
};
