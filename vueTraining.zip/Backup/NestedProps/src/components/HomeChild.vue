<template>
  <div>
    <h1>Child Components of Home</h1>
    <slot name="description"></slot>
    <br />
    <ul>
      <li v-for="user in usersLIstComputed" :key="user.id">{{ user.name }}</li>
    </ul>
    <h2>{{ reverseName }}</h2>
    <own-child :usersListToChild="usersList"></own-child>
  </div>
</template>

<script>
import OwnChild from "./ChildOfHome.vue";
export default {
  components: {
    OwnChild
  },
  props: {
    usersList: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      name: "Shakeel",
      profile: [
        {
          id: 1,
          url: "http://google.com"
        }
      ]
    };
  },
  computed: {
    usersLIstComputed() {
      return this.usersList;
    },
    reverseName() {
      return this.name
        .split("")
        .reverse()
        .join("");
    }
  }
};
</script>
