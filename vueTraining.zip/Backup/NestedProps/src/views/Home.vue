<template>
  <div class="home">
    <child-home :usersList="users">
      <p slot="description">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo nesciunt
        consequuntur laborum architecto, eum praesentium debitis. Iusto sint
        saepe adipisci nobis, beatae molestias iure repellendus hic amet
        corporis dicta impedit?
      </p>
    </child-home>
  </div>
</template>

<script>
import ChildHome from "../components/HomeChild.vue";
export default {
  data() {
    return {
      users: [
        {
          id: 1,
          name: "Shakeel"
        },
        {
          id: 2,
          name: "Amit"
        },
        {
          id: 3,
          name: "Rahul"
        },
        {
          id: 4,
          name: "Jeet"
        },
        {
          id: 5,
          name: "Vivek"
        }
      ]
    };
  },
  components: {
    ChildHome
  }
};
</script>
