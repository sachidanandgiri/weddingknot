<template>
  <div class="home">
    <p v-bgColor="{ bg: 'red' }">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur magnam
      quae, odit culpa consequatur vitae praesentium ducimus sequi obcaecati
      aliquam ipsam accusamus vel illo repellendus voluptates itaque, ab
      quibusdam id.
    </p>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>
