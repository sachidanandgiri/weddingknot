<template>
  <div class="home">
    <button @click="status = !status">Show/Hide</button>
    <p v-if="status">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur magnam
      quae, odit culpa consequatur vitae praesentium ducimus sequi obcaecati
      aliquam ipsam accusamus vel illo repellendus voluptates itaque, ab
      quibusdam id.
    </p>
    <p v-else>Else data</p>
    <span v-html="url"></span>
    <ul>
      <li v-for="(user, index) in users" :key="index">
        {{ user.name }} - index {{ index }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      status: true,
      url: "<a href='google.com'>Google</a>",
      users: [
        {
          id: 1,
          name: "shakeel"
        },
        {
          id: 2,
          name: "Amit"
        },
        {
          id: 3,
          name: "Rahul"
        },
        {
          id: 4,
          name: "Jeet"
        }
      ]
    };
  }
};
</script>
