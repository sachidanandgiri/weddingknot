<template>
  <div>
    <h1>Child Components of Home Child</h1>
    <slot name="description"></slot>
    <br />
    <ul>
      <li v-for="user in usersListToChild" :key="user.id">{{ user.name }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ["usersListToChild"]
};
</script>
