<template>
  <div>
    <h1>Child Components of Home</h1>
    <slot name="description"></slot>
    <br />
    <ul>
      <li v-for="user in usersList" :key="user.id">{{ user.name }}</li>
    </ul>
    <button @click="Send">Send To Parent</button>
  </div>
</template>

<script>
export default {
  props: {
    usersList: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      profiles: [
        {
          id: 1,
          url: "dfkjaskldfhkashdf"
        },
        {
          id: 2,
          url: "sdfgsdfgsdfg"
        }
      ]
    };
  },
  methods: {
    Send() {
      this.$emit("emmitedProfile", this.profiles);
    }
  }
};
</script>
