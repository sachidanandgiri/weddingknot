<template>
  <div class="home">
    <child-home :usersList="users" @emmitedProfile="getData">
      <p slot="description">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nemo nesciunt
        consequuntur laborum architecto, eum praesentium debitis. Iusto sint
        saepe adipisci nobis, beatae molestias iure repellendus hic amet
        corporis dicta impedit?
      </p>
    </child-home>
    <ul>
      <li v-for="profile in profiles" :key="profile.id">{{ profile.url }}</li>
    </ul>
  </div>
</template>

<script>
import ChildHome from "../components/HomeChild.vue";
export default {
  data() {
    return {
      users: [
        {
          id: 1,
          name: "Shakeel"
        },
        {
          id: 2,
          name: "Amit"
        },
        {
          id: 3,
          name: "Rahul"
        },
        {
          id: 4,
          name: "Jeet"
        },
        {
          id: 5,
          name: "Vivek"
        }
      ],
      profiles: null
    };
  },
  components: {
    ChildHome
  },
  methods: {
    getData(data) {
      this.profiles = data;
    }
  }
};
</script>
