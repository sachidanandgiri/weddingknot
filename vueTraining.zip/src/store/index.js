import Vue from "vue";
import Vuex from "vuex";

import counterPosts from "./modules/counterPost";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    counterPosts
  }
});
