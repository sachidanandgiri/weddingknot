import axios from "axios";

var state = {
  counter: 10,
  users: {}
};

var getters = {
  getCounter(state) {
    return state.counter;
  },
  getUsersState(state) {
    return state.users;
  }
};

var mutations = {
  increment(state, payload) {
    state.counter = state.counter + payload;
  },
  setUsers(state, data) {
    state.users = data;
  }
};

var actions = {
  incrementAction({ commit }, payload) {
    commit("increment", payload);
  },
  getUserAction({ commit }) {
    axios.get("https://jsonplaceholder.typicode.com/posts").then(result => {
      commit("setUsers", result.data);
    });
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
