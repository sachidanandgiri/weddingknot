<template>
  <div class="container">
    <h2>Parent</h2>
    <div class="panel panel-default">
      Parent : {{ getCounter }}
      <ul>
        <li v-for="post in getUsersState" :key="post.id">{{ post.title }}</li>
      </ul>
      <div class="panel-body">
        <child-one />
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import childOne from "../components/vuex/VuexChild.vue";
export default {
  components: {
    childOne
  },
  computed: {
    ...mapGetters(["getCounter", "getUsersState"])
  }
};
</script>
