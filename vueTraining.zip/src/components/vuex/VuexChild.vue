<template>
  <div class="container">
    <h2>Child One</h2>
    <div class="panel panel-default">
      Child : {{ getCounter }}
      <ul>
        <li v-for="post in getUsersState" :key="post.id">{{ post.title }}</li>
      </ul>
      <div class="panel-body">
        <childTwo />
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import childTwo from "./VuexChildOfChild.vue";
export default {
  components: {
    childTwo
  },
  computed: {
    ...mapGetters(["getCounter", "getUsersState"])
  }
};
</script>
