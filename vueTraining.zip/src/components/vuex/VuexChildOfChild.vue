<template>
  <div class="container">
    <h2>Child of One</h2>
    <div class="panel panel-default">
      Child of Child : {{ getCounter }}
      <ul>
        <li v-for="post in getUsersState" :key="post.id">{{ post.title }}</li>
      </ul>
      <div class="panel-body">
        <button @click="increment">Increment</button>
        <br />
        <br />
        <button @click="getUsers">GetUsers</button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  computed: {
    ...mapGetters(["getCounter", "getUsersState"])
  },
  methods: {
    ...mapActions(["incrementAction", "getUserAction"]),
    increment() {
      this.incrementAction(2);
    },
    getUsers() {
      this.getUserAction();
    }
  }
};
</script>
